<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    protected $table="lib_location";
	protected $fillable=['location_info','company','contact_person','contact_no','country','website','email','address','remarks','status'];
}
