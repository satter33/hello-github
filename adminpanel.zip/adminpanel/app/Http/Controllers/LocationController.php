<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests;
use App\Location;
class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data=Location::all();
        //print_r( $data);
        return view('pages.libraries.location', array('location_data' => $data));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //$input=$request->all();
        //$response=LibGroupDetails::create($input);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       $rules=array(
            'location_info' => 'required',
            'company' => 'required',
            'contact_person' => 'required',
            'contact_no' => 'required',
            'country' => 'required',
            'company' => 'required',
            'website' => 'required',
            'email' => 'required',
            'address' => 'required',
            'remarks' => 'required',
            'status' => 'required',
        );

    $validator = Validator::make($request->all(),$rules);
    if($validator->fails()) {
        return Redirect::back()
            ->withErrors($validator)
            ->WithInput();
        }
        else
        {
            $input=$request->all();
            $response=Location::create($input);
            if($response){
                $data=Location::all();
                return view('pages.libraries.location', ['location_data' => $data]);
            } 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $location_id = Location::findOrFail($id);
        $location_id->delete();

        Session::flash('flash_message', 'Task successfully deleted!');

        return redirect()->route('location.index');
    }
}
