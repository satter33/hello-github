<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    protected $table="main_module";
	protected $fillable=['id','main_module','module_root','file_name','status','mod_slno'];
}
