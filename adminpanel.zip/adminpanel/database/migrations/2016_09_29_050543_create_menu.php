<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenu extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //main module table
        Schema::create('main_menu', function($table)
        {
            $table->increments('id');
            $table->integer('m_module_id');
            $table->string('menu_name')->unique();
            $table->string('route_name');
            $table->string('root_menu');
            $table->string('sub_root_menu');
            $table->integer('status');
            $table->integer('menu_slno');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //drop main module
        Schema::drop(main_menu);
    }
}
