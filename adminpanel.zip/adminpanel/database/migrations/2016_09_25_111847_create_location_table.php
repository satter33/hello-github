<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLocationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('lib_location', function (Blueprint $table) {
            $table->increments('id');
            $table->string('location_info',100);
            $table->string('company',150);
            $table->string('contact_person',100);
            $table->integer('contact_no');
            $table->string('country',20);
            $table->string('website',100);
            $table->string('email',100);
            $table->text('address',300);
            $table->text('remarks',300);
            $table->integer('status');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('lib_location');
    }
}
