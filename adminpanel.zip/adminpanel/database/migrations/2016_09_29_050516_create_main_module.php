<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMainModule extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //main module table
        Schema::create('main_module', function($table)
        {
            $table->increments('id');
            $table->string('main_module')->unique();
            $table->string('file_name');
            $table->integer('status');
            $table->integer('mod_slno');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //drop main module
        Schema::drop(main_module);
    }
}
