@extends('layouts.layout')
@section('title','Welcome to my software')
@section('content')
<!-- Content Wrapper. Contains page content -->
        <section class="content-header" style="border-bottom:1px solid lightgray; text-align:center; padding-bottom:5px;">
           <h1>Welcome to My Software</h1>
        </section><!-- /.content -->
@endsection
