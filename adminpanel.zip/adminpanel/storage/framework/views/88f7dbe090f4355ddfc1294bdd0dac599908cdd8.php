<?php $__env->startSection('title','Welcome to my software'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
        <section class="content-header" style="border-bottom:1px solid lightgray; text-align:center; padding-bottom:5px;">
           <h1>Welcome to My Software</h1>
        </section><!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>