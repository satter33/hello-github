<?php $__env->startSection('title','Welcome to my software'); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
        <section>
        	<div class="panel panel-default" style="width:50%">
			  <div class="panel-heading" align="left">
			  	<!-- Trigger the modal with a button -->
				<button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal">Add Module</button>
			  </div>
			  <div class="panel-body">
			  	<table class="table table-striped">
				    <thead>
				      <tr>
				      	<th>SL</th>
				        <th>Module Name</th>
				         <th>Module Root</th>
				        <th>Status</th>
				        <th>Action</th>
				      </tr>
				    </thead>
				   
				  </table>
			  </div>
			  <div class="panel-footer"></div>
			</div>
			<!-- Modal -->
			<div id="myModal" class="modal fade" role="dialog">
			  <div class="modal-dialog">
			    <!-- Modal content-->
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal">&times;</button>
			        <h4 class="modal-title">Module</h4>
			      </div>
			      <div class="modal-body">
			       	<?php echo Form::open(array('url' => 'admin/main_module','class'=>'form-horizontal','id'=>'frmLocation')); ?>

			       		<div class="form-group has-feedback">
			       			<?php echo Form::label('module_name','Module Name',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('module_name','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('module_root','Module Root',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('module_root','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('file_name','File Name',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('file_name','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('staus','Status',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('staus','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group ">
					      <div class="col-sm-4"></div>
					      <div class="col-sm-4">
					      	<?php echo e(Form::submit('Submit',array('class'=>'btn btn-primary','id'=>'btn_submit'))); ?>

					      </div>
					      <div class="col-sm-1"></div>
					      <div class="col-sm-4">
					      	<?php echo e(Form::reset('Reset',array('class'=>'btn btn-primary','id'=>'btn_reset'))); ?>

					      </div>
					    </div>
			       	<?php echo Form::close(); ?>

			      </div>
			    </div>
			  </div>
			  <script>





			  </script>
			</div>
        </section><!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>