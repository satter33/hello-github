<?php $__env->startSection('title','Welcome to my software'); ?>
<?php $__env->startSection('content'); ?>
<?php $status=array('0'=>'--Select--','1'=>'Active','2'=>'Inactive');
$countries = array
(
	'AF' => 'Afghanistan',
	'AX' => 'Aland Islands',
	'AL' => 'Albania',
	'DZ' => 'Algeria',
	'AS' => 'American Samoa',
	'AD' => 'Andorra',
	'AO' => 'Angola',
	'AI' => 'Anguilla',
	'AQ' => 'Antarctica',
	'AG' => 'Antigua And Barbuda',
	'AR' => 'Argentina',
	'AM' => 'Armenia',
	'AW' => 'Aruba',
	'AU' => 'Australia',
	'AT' => 'Austria',
	'AZ' => 'Azerbaijan',
	'BS' => 'Bahamas',
	'BH' => 'Bahrain',
	'BD' => 'Bangladesh',
	'BB' => 'Barbados',
	'BY' => 'Belarus',
	'BE' => 'Belgium',
	'BZ' => 'Belize',
	'BJ' => 'Benin',
	'BM' => 'Bermuda',
	'BT' => 'Bhutan',
	'BO' => 'Bolivia',
	'BA' => 'Bosnia And Herzegovina',
	'BW' => 'Botswana',
	'BV' => 'Bouvet Island',
	'BR' => 'Brazil',
	'IO' => 'British Indian Ocean Territory',
	'BN' => 'Brunei Darussalam',
	'BG' => 'Bulgaria',
	'BF' => 'Burkina Faso',
	'BI' => 'Burundi',
	'KH' => 'Cambodia',
	'CM' => 'Cameroon',
	'CA' => 'Canada',
	'CV' => 'Cape Verde',
	'KY' => 'Cayman Islands',
	'CF' => 'Central African Republic',
	'TD' => 'Chad',
	'CL' => 'Chile',
	'CN' => 'China',
	'CX' => 'Christmas Island',
	'CC' => 'Cocos (Keeling) Islands',
	'CO' => 'Colombia',
	'KM' => 'Comoros',
	'CG' => 'Congo',
	'CD' => 'Congo, Democratic Republic',
	'CK' => 'Cook Islands',
	'CR' => 'Costa Rica',
	'CI' => 'Cote D\'Ivoire',
	'HR' => 'Croatia',
	'CU' => 'Cuba',
	'CY' => 'Cyprus',
	'CZ' => 'Czech Republic',
	'DK' => 'Denmark',
	'DJ' => 'Djibouti',
	'DM' => 'Dominica',
	'DO' => 'Dominican Republic',
	'EC' => 'Ecuador',
	'EG' => 'Egypt',
	'SV' => 'El Salvador',
	'GQ' => 'Equatorial Guinea',
	'ER' => 'Eritrea',
	'EE' => 'Estonia',
	'ET' => 'Ethiopia',
	'FK' => 'Falkland Islands (Malvinas)',
	'FO' => 'Faroe Islands',
	'FJ' => 'Fiji',
	'FI' => 'Finland',
	'FR' => 'France',
	'GF' => 'French Guiana',
	'PF' => 'French Polynesia',
	'TF' => 'French Southern Territories',
	'GA' => 'Gabon',
	'GM' => 'Gambia',
	'GE' => 'Georgia',
	'DE' => 'Germany',
	'GH' => 'Ghana',
	'GI' => 'Gibraltar',
	'GR' => 'Greece',
	'GL' => 'Greenland',
	'GD' => 'Grenada',
	'GP' => 'Guadeloupe',
	'GU' => 'Guam',
	'GT' => 'Guatemala',
	'GG' => 'Guernsey',
	'GN' => 'Guinea',
	'GW' => 'Guinea-Bissau',
	'GY' => 'Guyana',
	'HT' => 'Haiti',
	'HM' => 'Heard Island & Mcdonald Islands',
	'VA' => 'Holy See (Vatican City State)',
	'HN' => 'Honduras',
	'HK' => 'Hong Kong',
	'HU' => 'Hungary',
	'IS' => 'Iceland',
	'IN' => 'India',
	'ID' => 'Indonesia',
	'IR' => 'Iran, Islamic Republic Of',
	'IQ' => 'Iraq',
	'IE' => 'Ireland',
	'IM' => 'Isle Of Man',
	'IL' => 'Israel',
	'IT' => 'Italy',
	'JM' => 'Jamaica',
	'JP' => 'Japan',
	'JE' => 'Jersey',
	'JO' => 'Jordan',
	'KZ' => 'Kazakhstan',
	'KE' => 'Kenya',
	'KI' => 'Kiribati',
	'KR' => 'Korea',
	'KW' => 'Kuwait',
	'KG' => 'Kyrgyzstan',
	'LA' => 'Lao People\'s Democratic Republic',
	'LV' => 'Latvia',
	'LB' => 'Lebanon',
	'LS' => 'Lesotho',
	'LR' => 'Liberia',
	'LY' => 'Libyan Arab Jamahiriya',
	'LI' => 'Liechtenstein',
	'LT' => 'Lithuania',
	'LU' => 'Luxembourg',
	'MO' => 'Macao',
	'MK' => 'Macedonia',
	'MG' => 'Madagascar',
	'MW' => 'Malawi',
	'MY' => 'Malaysia',
	'MV' => 'Maldives',
	'ML' => 'Mali',
	'MT' => 'Malta',
	'MH' => 'Marshall Islands',
	'MQ' => 'Martinique',
	'MR' => 'Mauritania',
	'MU' => 'Mauritius',
	'YT' => 'Mayotte',
	'MX' => 'Mexico',
	'FM' => 'Micronesia, Federated States Of',
	'MD' => 'Moldova',
	'MC' => 'Monaco',
	'MN' => 'Mongolia',
	'ME' => 'Montenegro',
	'MS' => 'Montserrat',
	'MA' => 'Morocco',
	'MZ' => 'Mozambique',
	'MM' => 'Myanmar',
	'NA' => 'Namibia',
	'NR' => 'Nauru',
	'NP' => 'Nepal',
	'NL' => 'Netherlands',
	'AN' => 'Netherlands Antilles',
	'NC' => 'New Caledonia',
	'NZ' => 'New Zealand',
	'NI' => 'Nicaragua',
	'NE' => 'Niger',
	'NG' => 'Nigeria',
	'NU' => 'Niue',
	'NF' => 'Norfolk Island',
	'MP' => 'Northern Mariana Islands',
	'NO' => 'Norway',
	'OM' => 'Oman',
	'PK' => 'Pakistan',
	'PW' => 'Palau',
	'PS' => 'Palestinian Territory, Occupied',
	'PA' => 'Panama',
	'PG' => 'Papua New Guinea',
	'PY' => 'Paraguay',
	'PE' => 'Peru',
	'PH' => 'Philippines',
	'PN' => 'Pitcairn',
	'PL' => 'Poland',
	'PT' => 'Portugal',
	'PR' => 'Puerto Rico',
	'QA' => 'Qatar',
	'RE' => 'Reunion',
	'RO' => 'Romania',
	'RU' => 'Russian Federation',
	'RW' => 'Rwanda',
	'BL' => 'Saint Barthelemy',
	'SH' => 'Saint Helena',
	'KN' => 'Saint Kitts And Nevis',
	'LC' => 'Saint Lucia',
	'MF' => 'Saint Martin',
	'PM' => 'Saint Pierre And Miquelon',
	'VC' => 'Saint Vincent And Grenadines',
	'WS' => 'Samoa',
	'SM' => 'San Marino',
	'ST' => 'Sao Tome And Principe',
	'SA' => 'Saudi Arabia',
	'SN' => 'Senegal',
	'RS' => 'Serbia',
	'SC' => 'Seychelles',
	'SL' => 'Sierra Leone',
	'SG' => 'Singapore',
	'SK' => 'Slovakia',
	'SI' => 'Slovenia',
	'SB' => 'Solomon Islands',
	'SO' => 'Somalia',
	'ZA' => 'South Africa',
	'GS' => 'South Georgia And Sandwich Isl.',
	'ES' => 'Spain',
	'LK' => 'Sri Lanka',
	'SD' => 'Sudan',
	'SR' => 'Suriname',
	'SJ' => 'Svalbard And Jan Mayen',
	'SZ' => 'Swaziland',
	'SE' => 'Sweden',
	'CH' => 'Switzerland',
	'SY' => 'Syrian Arab Republic',
	'TW' => 'Taiwan',
	'TJ' => 'Tajikistan',
	'TZ' => 'Tanzania',
	'TH' => 'Thailand',
	'TL' => 'Timor-Leste',
	'TG' => 'Togo',
	'TK' => 'Tokelau',
	'TO' => 'Tonga',
	'TT' => 'Trinidad And Tobago',
	'TN' => 'Tunisia',
	'TR' => 'Turkey',
	'TM' => 'Turkmenistan',
	'TC' => 'Turks And Caicos Islands',
	'TV' => 'Tuvalu',
	'UG' => 'Uganda',
	'UA' => 'Ukraine',
	'AE' => 'United Arab Emirates',
	'GB' => 'United Kingdom',
	'US' => 'United States',
	'UM' => 'United States Outlying Islands',
	'UY' => 'Uruguay',
	'UZ' => 'Uzbekistan',
	'VU' => 'Vanuatu',
	'VE' => 'Venezuela',
	'VN' => 'Viet Nam',
	'VG' => 'Virgin Islands, British',
	'VI' => 'Virgin Islands, U.S.',
	'WF' => 'Wallis And Futuna',
	'EH' => 'Western Sahara',
	'YE' => 'Yemen',
	'ZM' => 'Zambia',
	'ZW' => 'Zimbabwe',
);
$company =array("Sunmoon Limited");
?>
<!-- Content Wrapper. Contains page content -->
        <section>
        	<div class="panel panel-default">
			  <div class="panel-heading">
			  	<!-- Trigger the modal with a button -->
				<button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal">Add Location</button>
			  </div>
			  <div class="panel-body">
			  	 <?php if(count($errors) > 0): ?>
		             <div >
		                 <ul class="alert alert-danger">
		                    <?php foreach($errors->all() as $error): ?>
		                       <li ><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                 </ul>
		              </div>
		        <?php endif; ?>
		        <main>
				    <div class="container">
				        <?php if(Session::has('flash_message')): ?>
				            <div class="alert alert-success">
				                <?php echo e(Session::get('flash_message')); ?>

				            </div>
				        <?php endif; ?>
				        
				        <?php echo $__env->yieldContent('content'); ?>
				    </div>
				</main>
			  	<table class="table table-striped">
				    <thead>
				      <tr>
				      	<th>SL</th>
				        <th>Location Info</th>
				        <th>Company Name</th>
				        <th>Contact Person</th>
				        <th>Contact No</th>
				        <th>Country</th>
				        <th>Website</th>
				        <th>Email</th>
				        <th>Address</th>
				        <th>Remarks</th>
				        <th>Status</th>
				        <th>Action</th>
				      </tr>
				    </thead>
				    <tbody style="font-size:12px;">
				    	<?php $i=1;?>
				     <?php foreach($location_data as $locat): ?>
				     <tr>
				     	<td><?php echo e($i); ?></td>
				     	<td ><?php echo e($locat->location_info); ?></td>
				     	<td><?php echo e($company[$locat->company]); ?></td>
				     	<td><?php echo e($locat->contact_person); ?></td>
				     	<td><?php echo e($locat->contact_no); ?></td>
				     	<td><?php echo e($countries[$locat->country]); ?></td>
				     	<td><?php echo e($locat->website); ?></td>
				     	<td><?php echo e($locat->email); ?></td>
				     	<td><?php echo e($locat->address); ?></td>
				     	<td><?php echo e($locat->remarks); ?></td>
				     	<td><?php echo e($status[$locat->status]); ?></td>
				     	<td><button type="button" class="btn btn-success btn-xs" data-id="<?php echo e($locat->id); ?>" onClick="editdataload(<?php echo e($locat->id); ?>)" id="edit<?php echo e($locat->id); ?>"><span class="glyphicon glyphicon-edit"></span></button></td>
				     	<td><button type="button" class="btn btn-success btn-xs" onClick="delete_data(<?php echo e($locat->id); ?>)" id="delete<?php echo e($locat->id); ?>"><span class="glyphicon glyphicon-trash"></span></button></td>
				     </tr>
				    <?php $i++;?>
				    <?php endforeach; ?>
				    </tbody>
				  </table>
			  </div>
			  <div class="panel-footer"></div>
			</div>
			<!-- Modal -->
			<div id="myModal" class="modal fade" role="dialog" >
			  <div class="modal-dialog">

			    <!-- Modal content-->
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal">&times;</button>
			        <h4 class="modal-title">Location</h4>
			      </div>
			      <div class="modal-body">
			       	<?php echo Form::open(array('url' => 'library/location','class'=>'form-horizontal','id'=>'frmLocation')); ?>

			       		<div class="form-group has-feedback">
			       			<?php echo Form::label('location_info','Location Information ',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('location_info','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('company','Company Name ',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					      	<?php echo Form::select('company',$company , null, array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('contact_person','Contact Person',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('contact_person','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('contact_no','Contact Number',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('contact_no','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('country','Country ',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					      	<?php echo Form::select('country',$countries , null, array('class' => 'form-control','style'=>'width:100%;')); ?>

					       
					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('website','Website',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('website','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('email','Email',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::email('email','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					     <div class="form-group has-feedback">
			       			<?php echo Form::label('address','Address',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('address','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('remarks','Remarks',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::text('remarks','',array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group has-feedback">
			       			<?php echo Form::label('status','Status',array('class'=>'col-sm-4 control-label') ); ?>

					      <div class="col-sm-8">
					        <?php echo Form::select('status',$status , null, array('class' => 'form-control','style'=>'width:100%;')); ?>

					      </div>
					    </div>
					    <div class="form-group ">
					      <div class="col-sm-4"></div>
					      <div class="col-sm-4">
					      	<?php echo e(Form::button('Submit',array('class'=>'btn btn-primary','id'=>'btn_submit'))); ?>

					      </div>
					      <div class="col-sm-1"></div>
					      <div class="col-sm-4">
					      	<?php echo e(Form::reset('Reset',array('class'=>'btn btn-primary','id'=>'btn_reset'))); ?>

					      </div>
					    </div>
			       	<?php echo Form::close(); ?>

			      </div>
			    </div>
			  </div>
			</div>
			<script>
			$(document).ready(function(){
				$('#frmLocation').on('click','#btn_submit',function(event){
					 event.preventDefault();
					formnam=$('#frmLocation');
					 url="location";
                     type="post";
                     data= formnam.serialize();	
                     $.ajax({
                     	url:url,
                     	type: type,
                     	data: data,
                     	success: function(result){
                     		console.log(result);
                     	}

                     })
				});
			});
			function editdataload(id)
			{								
				$('#myModal').modal('show')
			}

			function delete_data(id){
				alert(id);
			}

			</script>
        </section><!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>