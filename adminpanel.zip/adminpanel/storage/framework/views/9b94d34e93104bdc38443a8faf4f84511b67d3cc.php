<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="treeview">
        <a href="#">
          <i class="fa fa-edit"></i> <span>Forms</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
        </ul>
      </li>
       <li class="treeview">
        <a href="#">
          <i class="fa fa-pie-chart"></i>
          <span>Charts</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
          <li><?php echo Html::link('/add_menu', 'Create Menu'); ?></li>
        </ul>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>