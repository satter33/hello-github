<?php echo $__env->make('menus.admin_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header" style="border-bottom:1px solid lightgray; padding-bottom:5px;">
          <h1>Admin</h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>