;

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header" style="border-bottom:1px solid lightgray; padding-bottom:5px;">
          <h1>Library</h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Library</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>
        <!-- Main content -->
        <section class="content">
     		<?php echo Form::open(); ?>

            	<div class="form-group">
                  <?php echo Form::label('email', 'E-Mail Address'); ?>

                  <?php echo Form::email('email',null,array('class' =>'form-control')); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('password', 'Password'); ?>

                  <?php echo Form::password('password',null,array('class' =>'form-control')); ?>

                 </div>
            <?php echo Form::close(); ?>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>