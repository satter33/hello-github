<?php $__env->startSection('menu'); ?>
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="active treeview">
        <a href="#">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li class="active"><a href="../index.html"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
          <li><a href="../index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-pie-chart"></i>
          <span>Charts</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><a href="../pages/charts/chartjs.html"><i class="fa fa-circle-o"></i> ChartJS</a></li>
          <li><a href="../pages/charts/morris.html"><i class="fa fa-circle-o"></i> Morris</a></li>
          <li><a href="../pages/charts/flot.html"><i class="fa fa-circle-o"></i> Flot</a></li>
          <li><a href="../pages/charts/inline.html"><i class="fa fa-circle-o"></i> Inline charts</a></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-laptop"></i>
          <span>UI Elements</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><a href="../pages/UI/general.html"><i class="fa fa-circle-o"></i> General</a></li>
          <li><a href="../pages/UI/icons.html"><i class="fa fa-circle-o"></i> Icons</a></li>
          <li><a href="../pages/UI/buttons.html"><i class="fa fa-circle-o"></i> Buttons</a></li>
          <li><a href="../pages/UI/sliders.html"><i class="fa fa-circle-o"></i> Sliders</a></li>
          <li><a href="../pages/UI/timeline.html"><i class="fa fa-circle-o"></i> Timeline</a></li>
          <li><a href="../pages/UI/modals.html"><i class="fa fa-circle-o"></i> Modals</a></li>
        </ul>
      </li> 
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header" style="border-bottom:1px solid lightgray; padding-bottom:5px;">
           <h1>Report</h1>
          	<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Report</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>