<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="treeview">
        <a href="#">
          <i class="fa fa-dashboard"></i> <span>Cost Center</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><?php echo Html::link("/library/group","Group Details"); ?></li>
          <li><?php echo Html::link("/library/division","Division Details"); ?></li>
          <li><?php echo Html::link("/library/department","Department Details"); ?></li>
          <li><?php echo Html::link("/library/section","Section Details"); ?></li>
          <li><?php echo Html::link("/library/subsection","Subsection Details"); ?></li>
        </ul>
      </li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-dashboard"></i> <span>HR & Admin</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><?php echo Html::link("/library/designation","Designation Chart"); ?></li>
          <li><?php echo Html::link("/library/payroll","Payroll Head"); ?></li>
          <li><?php echo Html::link("/library/template","Report Template"); ?></li>
          <li><?php echo Html::link("/library/document","Required Document"); ?></li>
          <li><?php echo Html::link("/library/training","Training Record"); ?></li>
          <li><?php echo Html::link("/library/designChart","Designation Chart"); ?></li>
          <li><?php echo Html::link("/library/payroll","Payroll Head"); ?></li>
          <li><?php echo Html::link("/library/department","Report Template"); ?></li>
          <li><?php echo Html::link("/library/section","Required Document"); ?></li>
          <li><?php echo Html::link("/library/subsection","Training Record"); ?></li>
        </ul>
      </li>
       <li class="treeview">
        <a href="#">
          <i class="fa fa-dashboard"></i> <span>Transport Setting</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><?php echo Html::link("/library/designation","Designation Chart"); ?></li>
          <li><?php echo Html::link("/library/payroll","Payroll Head"); ?></li>
          <li><?php echo Html::link("/library/template","Report Template"); ?></li>
          <li><?php echo Html::link("/library/document","Required Document"); ?></li>
          <li><?php echo Html::link("/library/training","Training Record"); ?></li>
          <li><?php echo Html::link("/library/designChart","Designation Chart"); ?></li>
          <li><?php echo Html::link("/library/payroll","Payroll Head"); ?></li>
          <li><?php echo Html::link("/library/department","Report Template"); ?></li>
          <li><?php echo Html::link("/library/section","Required Document"); ?></li>
          <li><?php echo Html::link("/library/subsection","Training Record"); ?></li>
        </ul>
      </li>
       <li class="treeview">
        <a href="#">
          <i class="fa fa-dashboard"></i> <span>Year</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><?php echo Html::link("/library/designation","Designation Chart"); ?></li>
          <li><?php echo Html::link("/library/payroll","Payroll Head"); ?></li>
          <li><?php echo Html::link("/library/template","Report Template"); ?></li>
          <li><?php echo Html::link("/library/document","Required Document"); ?></li>
          <li><?php echo Html::link("/library/training","Training Record"); ?></li>
          <li><?php echo Html::link("/library/designChart","Designation Chart"); ?></li>
          <li><?php echo Html::link("/library/payroll","Payroll Head"); ?></li>
          <li><?php echo Html::link("/library/department","Report Template"); ?></li>
          <li><?php echo Html::link("/library/section","Required Document"); ?></li>
          <li><?php echo Html::link("/library/subsection","Training Record"); ?></li>
        </ul>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>