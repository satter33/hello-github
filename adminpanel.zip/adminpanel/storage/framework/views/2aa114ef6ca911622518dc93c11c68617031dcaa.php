<?php echo $__env->make('headers.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue">
	<div class="wrapper">
    	<div>
            <?php echo $__env->make('menus.top_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            <!-- side menu lood-->
            <?php echo $__env->make('menus.side_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="content-wrapper clearfix" style="padding:60px 5% 0%;">
            <?php echo $__env->yieldContent('content'); ?>
     	</div>
		<footer class="main-footer">
	        <strong>Copyright &copy; 2014-2015 <a href="http://facebook.com/md.satter">M. A. Satter</a>.</strong> All rights reserved.
     	</footer>
	</div>
<?php echo $__env->make('headers.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>