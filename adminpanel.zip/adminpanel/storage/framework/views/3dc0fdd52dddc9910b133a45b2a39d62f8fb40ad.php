<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>My laravel project</title>
   <?php echo Html::style('css/mainsss.css'); ?>

</head>
<body>
	<div class="main">Im satter</div>
    <?php echo Form::open(array('url' => 'foo/bar')); ?>

    <? 
		echo Form::label('email', 'E-Mail'); 
		echo Form::text('email');
		echo Form::label('username', 'Username');
		echo Form::text('username');
	?>
	<?php echo Form::close(); ?>

</body>
</html>