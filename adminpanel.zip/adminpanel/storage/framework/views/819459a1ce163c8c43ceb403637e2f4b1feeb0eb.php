<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="treeview">
        
          <?php 
                $pathsss=explode("/",Request::path());
            ?>
             <!-- side menu lood-->
            <?php if($pathsss[0] ==="hrm"): ?>
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>Category One</span> <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><?php echo Html::link("/library/group","Sample one"); ?></li>
              <li><?php echo Html::link("/library/division","Sample one"); ?></li>
            </ul>
            <?php elseif($pathsss[0] ==="report"): ?>
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>Category One</span> <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><?php echo Html::link('admin/main_module', 'Module Management'); ?></li>
            </ul>
            <?php elseif($pathsss[0] ==="admin"): ?>
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>Category One</span> <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><?php echo Html::link("/library/group","Sample one"); ?></li>
              <li><?php echo Html::link("/library/division","Sample one"); ?></li>
            </ul>
            <?php elseif($pathsss[0] ==="library"): ?>
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>Cost Center</span> <i class="fa fa-angle-left pull-right"></i>
            </a>
            <ul class="treeview-menu">
              <li><?php echo Html::link("/location","Location Details"); ?></li>
              <li><?php echo Html::link("/library/division","Division Details"); ?></li>
              <li><?php echo Html::link("/library/division","Department Details"); ?></li>
              <li><?php echo Html::link("/library/division","Section Details"); ?></li>
              <li><?php echo Html::link("/library/division","Subsection Details"); ?></li>
            </ul>
            <?php endif; ?>
      </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>